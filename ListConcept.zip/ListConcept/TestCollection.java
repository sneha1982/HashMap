import java.util.*;
class TestCollection
{
      public static void main(String[] args)
     {
           TreeSet<Integer> ts = new TreeSet<Integer>();
               ts.add(100);
               ts.add(155);
               ts.add(230);
               ts.add(333);
               for(Integer itr:ts)
               {
               System.out.println(itr);
               }
               
     
}
     
}