package ListConcept;
public class Employee{
String name;
int age;
String dept;
Employee(String name, int age, String dept){
this.name = name;
this.age = age;
this.dept = dept;

}
}

