package ListConcept;
import java.util.HashMap;
import java.util.Map;

public class HashMapConcept{
public static void main(String[]args){


HashMap<Integer, String> hm = new HashMap<Integer, String>();
hm.put(1,"Sneha");
hm.put(2,"Sangeeta");
hm.put(3,"bindi");

System.out.println(hm.get(1));
System.out.println(hm.get(2));
System.out.println(hm.get(3));
}
}