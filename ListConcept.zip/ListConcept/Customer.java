import java.util;
class Customer
{
   private int custId;
   private int custAge;
   public Customer(int custId, int custAge)
}