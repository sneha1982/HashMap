package testcases;
public class ReverseString{

public static void main(String[]args)
{
 String s = "Sneha";
 
 StringBuffer sf = new StringBuffer(s);
 System.out.println(sf.reverse());
 
}
}