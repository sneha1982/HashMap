/*
First Condition
To qualify as instant accept, all of the following criteria must be met. 
 1. in-state (California) age 17 or older, and younger than 26; or older than 80 from any state. 1
 2. High School GPA of 90% or higher of scale provided in their application.  For example, 3.6 on a 4.0 scale;  or 4.5 on a 5.0 scale.   
 3. SAT score greater than 1920 or ACT score greater than 27.  Note:  Both, or only one of these, may be present in the applicant. 
 4. No �instant reject� criteria is hit (see below). 
 
 Secound condition
 1. All applicants can be subject to instant reject, if they meet any of the following criteria.  Some of the criteria is dubious, admittedly, but the Dean insisted on it
 2. 1 or more felonies over the past 5 years. 
 3. High School GPA below 70% of scale provided on application.  For example, 2.8 on a 4.0 scale. o 
 4. The applicant claimed to be a negative age (it happens!) e.g. �-20� years old.
 5. The applicant�s first and/or last name are not in the form of first letter capitalized, the 
rest lower case.
 
third condition
1. If the candidate does not qualify for instant accept nor qualifies for instant reject, then they should be flagged for further review instead. 
*/
public class ResumeAplication{

public static void main(String[]args){
  int age = x;
  string state = y;
  double GPA = z;
  if (x>= 17 && x < 26 ||( age > 80)){
  System.out.print("instant aceept");
  }
  else {
  System.out.print("instant reject");
  
  
 
}
}
} 